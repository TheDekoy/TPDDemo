export namespace TPDConstants {

//  export const baseurl: string = "http://localhost:8080/TPDRESTServer/tpdrest";
  export const baseurl: string = "http://shopping.torquepower.com.au/TPDRESTServer/tpdrest";

  export const OK = 200;
  export const FORBIDDEN = 403;
  export const UNAVAILABLE = 503;

}