export interface Money {
    cents: string;
    dollars: string;
    sign: boolean;
    value: number;
}