export interface Category {

    code: string;
    description: string;
}