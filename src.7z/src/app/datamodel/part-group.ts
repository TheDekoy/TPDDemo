export interface PartGroup {

    code: string;
    description: string;
}