export interface EngineModel {

    code: string;
    description: string;
}