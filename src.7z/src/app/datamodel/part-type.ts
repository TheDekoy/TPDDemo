export interface PartType {

    code: string;
    description: string;
}