import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-retailportal',
  templateUrl: './retailportal.component.html',
  styleUrls: ['./retailportal.component.css']
})
export class RetailportalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
