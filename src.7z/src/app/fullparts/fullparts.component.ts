import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-fullparts',
  templateUrl: './fullparts.component.html',
  styleUrls: ['./fullparts.component.css']
})
export class FullpartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
